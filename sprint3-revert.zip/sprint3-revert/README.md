# Store-Service Microservice

## Sprint Details -

* Create Store Schema. 
* User should be able to get details of any Store using its storeid or an array of storeids. 
* User should be able to get details of all the stores available in the master catalogue. 
* User should be able to add more stores to the master catalogue. 
* User should be able to update any store’s attributes on the basis of its storeid. 
* User should be able to delete a single store using its storeid or a range of stores using an array of storeids. 
* In case of API failure, proper error handling should be implemented to avoid cascading failures. 


## Tech
* [SpringBoot](https://spring.io/projects/spring-boot) Framework in use with java11 and Maven.
* [Spring Web](https://spring.io/guides/gs/spring-boot/) Build web, including RESTful, applications using Spring MVC and Tomcat server.
* [Spring Data JPA](https://spring.io/projects/spring-data-jpa) Persist data in SQL stores with Java Persistence API using Spring Data and Hibernate.
* [PostgreSQL Driver](https://jdbc.postgresql.org) JDBC Connection with postgresql.


## Installation

Store Service Requires java11+ and Maven to run.

```sh
$ cd Store-Service
$ mvn install
$ mvn spring-boot:run
```
