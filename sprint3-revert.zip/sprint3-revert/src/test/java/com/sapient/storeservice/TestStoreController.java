package com.sapient.storeservice;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sapient.storeservice.models.Address;
import com.sapient.storeservice.models.Store;
import com.sapient.storeservice.repository.StoreRepository;

import io.restassured.RestAssured;
import io.restassured.response.Response;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, properties = {
		"spring.jpa.hibernate.ddl-auto=create-drop", "spring.liquibase.enabled=false", "spring.flyway.enabled=false" })
class TestStoreController {

	@Autowired
	private StoreRepository storeRepository;

	private Address address1, address2;

	private Store store1, store2;
	
	private Long ids[] = new Long[2];

	private List<Store> stores = new ArrayList<Store>();
	
	
	@BeforeEach
	void setUp() throws Exception {
		RestAssured.baseURI = "http://localhost";
		RestAssured.port = 8080;
		address1 = new Address("laneeee1", "laeeene1", 1110000);
		store1 = new Store("first", "11000000", address1);
		address2 = new Address("laneeee2", "laeeene2", 1110000);
		store2 = new Store("second", "22000000", address2);
		stores.add(store1);
		stores.add(store2);
		ids[0]= storeRepository.save(store1).getStoreId();
		ids[1]= storeRepository.save(store2).getStoreId();
	}
	
	
	@Test
	public void createTutorialTest() {

		// checking for status 200(OK)
		Response response = given().contentType("application/json").accept("application/json").body(stores).when()
				.post("/api/stores").then().statusCode(201).contentType("application/json").extract().response();

		List<Long> storeids = response.jsonPath().getList("storeId");
		List<String> storename = response.jsonPath().getList("storeName");
		List<String> storephonenumber = response.jsonPath().getList("storePhoneNumber");
		List<Long> addressids = response.jsonPath().getList("storeAddress.addressId");
		List<String> storeAddresslinetwo = response.jsonPath().getList("storeAddress.addressLineTwo");
		List<String> storeAddresslineone = response.jsonPath().getList("storeAddress.addressLineOne");
		List<Integer> storeAddresspin = response.jsonPath().getList("storeAddress.addressPin");

		assertNotNull(storeids);
		assertNotNull(addressids);
		for(int i=0;i<2;i++) {
		assertEquals(storename.get(i), stores.get(i).getStoreName());
		assertEquals(storephonenumber.get(i), stores.get(i).getStorePhoneNumber());
		assertEquals(storeAddresslineone.get(i), stores.get(i).getStoreAddress().getAddressLineOne());
		assertEquals(storeAddresslinetwo.get(i), stores.get(i).getStoreAddress().getAddressLineTwo());
		assertEquals(storeAddresspin.get(i), stores.get(i).getStoreAddress().getAddressPin());
		}
	}
	@Test
    public void CreateEmptyListofStore() {
    List<Store> store = new ArrayList<Store>();
    given().contentType("application/json").accept("application/json").body(store).when().post("api/stores").then().statusCode(204).extract().response();
    }
   
    @Test
    public void CreateStoreBadRequest() {
    Store store =  new Store();
    given().contentType("application/json").accept("application/json").body(store).when().post("api/stores").then().statusCode(400).extract().response();
    }
	@Test
	public void GetOneStoreTest() {
		
		Response response = given().contentType("application/json").accept("application/json").body(ids).when()
				.get("/api/stores").then().statusCode(200).contentType("application/json").extract().response();

		List<Long> storeids = response.jsonPath().getList("storeId");
		List<String> storename = response.jsonPath().getList("storeName");
		List<String> storephonenumber = response.jsonPath().getList("storePhoneNumber");
		List<Long> addressids = response.jsonPath().getList("storeAddress.addressId");
		List<String> storeAddresslinetwo = response.jsonPath().getList("storeAddress.addressLineTwo");
		List<String> storeAddresslineone = response.jsonPath().getList("storeAddress.addressLineOne");
		List<Integer> storeAddresspin = response.jsonPath().getList("storeAddress.addressPin");
		
		assertNotNull(storeids);
		assertNotNull(addressids);
			assertEquals(storename.get(0), stores.get(0).getStoreName());
			assertEquals(storephonenumber.get(0), stores.get(0).getStorePhoneNumber());
			assertEquals(storeAddresslineone.get(0), stores.get(0).getStoreAddress().getAddressLineOne());
			assertEquals(storeAddresslinetwo.get(0), stores.get(0).getStoreAddress().getAddressLineTwo());
			assertEquals(storeAddresspin.get(0), stores.get(0).getStoreAddress().getAddressPin());

	}

	
	@Test
	public void GetListOfStoresTest(){
         	
		Response response = given().contentType("application/json").accept("application/json").body(ids).when()
				.get("/api/stores").then().statusCode(200).contentType("application/json").extract().response();

		List<Long> storeids = response.jsonPath().getList("storeId");
		List<String> storename = response.jsonPath().getList("storeName");
		List<String> storephonenumber = response.jsonPath().getList("storePhoneNumber");
		List<Long> addressids = response.jsonPath().getList("storeAddress.addressId");
		List<String> storeAddresslinetwo = response.jsonPath().getList("storeAddress.addressLineTwo");
		List<String> storeAddresslineone = response.jsonPath().getList("storeAddress.addressLineOne");
		List<Integer> storeAddresspin = response.jsonPath().getList("storeAddress.addressPin");

		assertNotNull(storeids);
		assertNotNull(addressids);
		for(int i=0;i<storeids.size();i++) {
			assertEquals(storename.get(i), stores.get(i).getStoreName());
			assertEquals(storephonenumber.get(i), stores.get(i).getStorePhoneNumber());
			assertEquals(storeAddresslineone.get(i), stores.get(i).getStoreAddress().getAddressLineOne());
			assertEquals(storeAddresslinetwo.get(i), stores.get(i).getStoreAddress().getAddressLineTwo());
			assertEquals(storeAddresspin.get(i), stores.get(i).getStoreAddress().getAddressPin());
			}
		
	}
	
	@Test
	public void GetALLStoresTest() {
		Response response = given().contentType("application/json").accept("application/json").when()
				.get("api/stores/all").then().statusCode(200).extract().response();
		
		List<Long> storeids = response.jsonPath().getList("storeId");
		List<Long> addressids = response.jsonPath().getList("storeAddress.addressId");
		List<String> storename = response.jsonPath().getList("storeName");
		List<String> storephonenumber = response.jsonPath().getList("storePhoneNumber");
		List<String> storeAddresslinetwo = response.jsonPath().getList("storeAddress.addressLineTwo");
		List<String> storeAddresslineone = response.jsonPath().getList("storeAddress.addressLineOne");
		List<Integer> storeAddresspin = response.jsonPath().getList("storeAddress.addressPin");
		
		assertNotNull(storeids);
		assertNotNull(addressids);
		
		for(int i=0;i<storeids.size();i++) {
			assertEquals(storename.get(i), stores.get(i).getStoreName());
			assertEquals(storephonenumber.get(i), stores.get(i).getStorePhoneNumber());
			assertEquals(storeAddresslineone.get(i), stores.get(i).getStoreAddress().getAddressLineOne());
			assertEquals(storeAddresslinetwo.get(i), stores.get(i).getStoreAddress().getAddressLineTwo());
			assertEquals(storeAddresspin.get(i), stores.get(i).getStoreAddress().getAddressPin());
			}
	}
	@Test
	public void GetEmptyListOfStoresTest() {
		Long[] id_list = {};
		given().contentType("application/json").accept("application/json").body(id_list).when()
				.get("api/stores").then().statusCode(404);

	}
	@Test
	public void GetStoreWithInvalidIDTest() {
		Long[] id_list = { (long) -1};
		given().contentType("application/json").accept("application/json").body(id_list).when()
				.get("api/stores").then().statusCode(404);

	}
	
	@Test
	public void GetALLStoresWhenNoStorePresentTest() {
		storeRepository.deleteAll();
		given().contentType("application/json").accept("application/json").when()
				.get("api/stores/all").then().statusCode(404);
	}
	
	
	@Test
    public void updateStoreSuccess() {
      
        Address address1_update = new Address("lane6", "lane6", 4566);
        Store store1_update = new Store("first", "222", address1_update);
            store1_update.setStoreId(1);
        
         Response response = given().contentType("application/json").accept("application/json").body(store1_update)
                .when().put("/api/stores").then().statusCode(200).contentType("application/json").extract().response();
        assertEquals(response.jsonPath().getLong("storeId"), store1_update.getStoreId());
        assertEquals(response.jsonPath().getString("storeName"), store1_update.getStoreName());
        assertEquals(response.jsonPath().getString("storePhoneNumber"), store1_update.getStorePhoneNumber());
        
        assertEquals(response.jsonPath().getString("storeAddress.addressLineOne"),
                store1_update.getStoreAddress().getAddressLineOne());
        assertEquals(response.jsonPath().getString("storeAddress.addressLineTwo"),
                store1_update.getStoreAddress().getAddressLineTwo());
        assertEquals(response.jsonPath().getInt("storeAddress.addressPin"),
                store1_update.getStoreAddress().getAddressPin());
    }

 

    @Test
    public void updateStoreNotFound() {
        Address address1_update = new Address("lane4", "lane4", 4444);
        Store store1_update = new Store("first", "11111", address1_update);
        store1_update.setStoreId(2223);
        given().contentType("application/json").accept("application/json").body(store1_update).when().put("/api/stores")
                .then().statusCode(404);
    }
	
    
	@Test
	public void DeleteOneStoreTest() {
		Long[] id_list = { ids[0] };
	      given().contentType("application/json").accept("application/json").body(id_list).when()
				.delete("api/stores").then().statusCode(200);

	}

	@Test
	public void DeleteListOfStoresTest() {
		Long[] id_list = { (long) 2, (long) 3 };
		given().contentType("application/json").accept("application/json").body(id_list).when()
				.delete("api/stores").then().statusCode(404);

	}

	@Test
	public void DeleteALLStoresTest() {
		given().contentType("application/json").accept("application/json").when()
				.delete("api/stores/all").then().statusCode(200);
	}

	@Test
	public void DeleteEmptyListOfStoresTest() {
		Long[] id_list = {};
		given().contentType("application/json").accept("application/json").body(id_list).when()
				.delete("api/stores").then().statusCode(404);

	}
  
	@Test
	public void DeleteStoreWithInvalidIDTest() {
		Long[] id_list = { (long) -1 };
		 given().contentType("application/json").accept("application/json").body(id_list).when()
				.delete("api/stores").then().statusCode(404);

	}

	/*@Test
	public void DeleteALLStoresWhenNoStorePresentTest() {
		 given().contentType("application/json").accept("application/json").when()
				.delete("api/stores/all").then().statusCode(200);
	}*/
	@Test
    public void DeleteALLStoresWhenNoStorePresentTest() {
	//Long[] ids = {];
        
        storeRepository.deleteAll();
        
        Response response = given().contentType("application/json").accept("application/json").when()
                .delete("api/stores/all").then().statusCode(404).extract().response();
    }
	@AfterEach
	void clean() throws Exception {
		storeRepository.delete(store1);
	    storeRepository.delete(store2);
	}

}
