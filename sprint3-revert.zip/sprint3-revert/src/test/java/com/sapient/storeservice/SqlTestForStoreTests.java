package com.sapient.storeservice;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sapient.storeservice.models.Address;
import com.sapient.storeservice.models.Store;
import com.sapient.storeservice.repository.StoreRepository;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, properties = {
		"spring.jpa.hibernate.ddl-auto=create-drop", "spring.liquibase.enabled=false", "spring.flyway.enabled=false" })
public class SqlTestForStoreTests {
	
	@Autowired
	  private StoreRepository storeRepository;

	@Test
    public void saveStoreTest() {

		Address address = new Address("lane1","lane2",110077);
        Store store = new Store("Dhaba", "9999999999", address);
        storeRepository.save(store);
        List<Store> store2 = storeRepository.findByStoreName("Dhaba");
        assertNotNull(store2);
        assertEquals(store2.get(0).getStoreName(), store.getStoreName());
        assertEquals(store2.get(0).getStorePhoneNumber(), store.getStorePhoneNumber());
        assertEquals(store2.get(0).getStoreAddress().getAddressLineOne(), store.getStoreAddress().getAddressLineOne());
        assertEquals(store2.get(0).getStoreAddress().getAddressLineTwo(), store.getStoreAddress().getAddressLineTwo());
        assertEquals(store2.get(0).getStoreAddress().getAddressPin(), store.getStoreAddress().getAddressPin());
    }

    @Test
    public void getStoreByIdTest() {

    	Address address = new Address("lane1","lane2",110077);
        Store store = new Store("Dhaba", "9999999999", address);
        Store store3 = storeRepository.save(store);
        Optional<Store> store2 = storeRepository.findById(store3.getStoreId());
        
        assertNotNull(store2.isPresent());
        assertEquals(store2.get().getStoreName(), store.getStoreName());
        assertEquals(store2.get().getStorePhoneNumber(), store.getStorePhoneNumber());
    }

    @Test
    public void testDeleteStoreTest() {
    	Address address = new Address("lane1","lane2",110077);
        Store store = new Store("Dhaba", "9999999999", address);
        Store store2 = storeRepository.save(store);
        storeRepository.delete(store);
        assertThrows(NoSuchElementException.class, () -> storeRepository.findById(store2.getStoreId()).get());
    }

    @Test
    public void findAllStoresTest() {
    	Address address = new Address("lane1","lane2",110077);
        Store store = new Store("Dhaba", "9999999999", address);
        storeRepository.save(store);
        assertNotNull(storeRepository.findAll());
    }

    @Test
    public void deletByStoreIdTest() {
    	Address address = new Address("lane1","lane2",110077);
        Store store = new Store("Dhaba", "9999999999", address);
        Store store2 = storeRepository.save(store);
        storeRepository.deleteById(store2.getStoreId());
        assertThrows(NoSuchElementException.class, () -> storeRepository.findById(store2.getStoreId()).get());
    }

}
