package com.sapient.storeservice;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, properties = {
		"spring.jpa.hibernate.ddl-auto=create-drop", "spring.liquibase.enabled=false", "spring.flyway.enabled=false" })
class StoreServiceApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
