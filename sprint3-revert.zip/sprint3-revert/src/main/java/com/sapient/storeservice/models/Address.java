package com.sapient.storeservice.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "address")
@Table(name = "Address")
public class Address {
	
	@Id
	@GeneratedValue
	@Column(name = "address_id")
	private long addressId;
	
	@Column(name = "line1")
	private String addressLineOne;
	
	@Column(name = "line2")
	private String addressLineTwo;
	
	@Column(name = "pin")
	private Integer addressPin;

	public Address() {
		super();
	}

	public Address(String addressLineOne, String addressLineTwo, Integer addressPin) {
		super();
		this.addressLineOne = addressLineOne;
		this.addressLineTwo = addressLineTwo;
		this.addressPin = addressPin;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", addressLineOne=" + addressLineOne + ", addressLineTwo="
				+ addressLineTwo + ", addressPin=" + addressPin + "]";
	}

	public long getAddressId() {
		return addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public String getAddressLineOne() {
		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	public Integer getAddressPin() {
		return addressPin;
	}

	public void setAddressPin(Integer addressPin) {
		this.addressPin = addressPin;
	}
	
	
	
	

	
	
	
	

}
