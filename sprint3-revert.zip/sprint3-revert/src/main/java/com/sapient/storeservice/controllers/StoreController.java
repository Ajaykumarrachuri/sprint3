package com.sapient.storeservice.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.storeservice.exceptions.EmptyIDListException;
import com.sapient.storeservice.exceptions.StoreNotFoundException;
import com.sapient.storeservice.models.Store;
import com.sapient.storeservice.repository.StoreRepository;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/api")
public class StoreController {

	@Autowired
	StoreRepository storeRepository;

    @GetMapping("/stores")
	public ResponseEntity<List<Store>> getStore(@RequestBody Long[] id) {
			if(id.length == 0)
				throw new EmptyIDListException("ID List is Empty");
			List<Store> stores= new ArrayList<Store>();
			try {
			stores = storeRepository.findAllById(Arrays.asList(id));
			}
			catch(Exception e) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			if(!stores.isEmpty())
			   return new ResponseEntity<>(stores, HttpStatus.OK);
			else 
			   throw new StoreNotFoundException("Stores Not Found");	
	}
	

	@GetMapping("/stores/all")
	public ResponseEntity<List<Store>> getAllStores() {
		
			List<Store> stores = new ArrayList<Store>();
			try {
			stores = storeRepository.findAll();
			}
			catch (Exception e) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			if (stores.isEmpty()) {
				throw new StoreNotFoundException("Stores Not Found");
			}
			return new ResponseEntity<>(stores, HttpStatus.OK);
		} 
	
	@PostMapping("/stores")
    public ResponseEntity<List<Store>> createStore(@RequestBody ArrayList<Store> store) {
        try {
           
            if(store.size() == 0) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            List<Store> _store = new ArrayList<Store>();
            _store =     storeRepository.saveAll(store);
           
            return new ResponseEntity<>(_store, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(store, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	@PutMapping("/stores")
    public ResponseEntity<Store> updateStoreById(@RequestBody Store store) throws StoreNotFoundException{
		 Optional<Store> storeData;
		    try {
             storeData = storeRepository.findById(store.getStoreId());
		    }
		    catch(Exception e) {
		    	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		    }
            if (storeData.isPresent()) {
                Store _store = storeData.get();
                _store.setStoreName(store.getStoreName());
                _store.setStorePhoneNumber(store.getStorePhoneNumber());
                _store.setStoreAddress(store.getStoreAddress());
                storeRepository.save(_store);
                return new ResponseEntity<>(_store, HttpStatus.OK);
            } 
            else {
                throw new StoreNotFoundException("Stores Not Found");
            }
    }


	@DeleteMapping("/stores/all")
	public ResponseEntity<List<Store>> deleteAllStores() {
		List<Store> stores = new ArrayList<>();
		try {
			stores = storeRepository.findAll();
			}
			catch(Exception e) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		
		if (stores.size() == 0) {
			throw new StoreNotFoundException("Stores Not Found");
		}
		storeRepository.deleteAll();
		return new ResponseEntity<>(stores, HttpStatus.OK);

	}

	
	@Transactional
	@DeleteMapping("/stores")
	public ResponseEntity<List<Store>> deleteStoresById(@RequestBody Long[] ids) {
		List<Store> stores;
		
		if(ids.length == 0)
			throw new EmptyIDListException("ID List is Empty");
		try {
			stores = storeRepository.findAllById(Arrays.asList(ids));
			}
			catch(Exception e) {
				return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		if (stores.isEmpty()) {
			throw new StoreNotFoundException("Stores Not Found");
		}
		storeRepository.deleteAll(stores);
		return new ResponseEntity<>(stores, HttpStatus.OK);

	}
}
