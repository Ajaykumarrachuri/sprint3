package com.sapient.storeservice.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity(name = "Store")
@Table(name = "Store")
public class Store {
	
	@Id
	@Column(name = "store_id")
	@GeneratedValue
	private long storeId;
	
	@Column(name = "store_name")
	private String storeName;
	
	@Column(name = "phone_no")
	private String storePhoneNumber;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id")
	private Address storeAddress;

	public Store() {
		super();
	}

	public Store(String storeName, String storePhoneNumber, Address storeAddress) {
		super();
		this.storeName = storeName;
		this.storePhoneNumber = storePhoneNumber;
		this.storeAddress = storeAddress;
	}

	@Override
	public String toString() {
		return "Store [storeId=" + storeId + ", storeName=" + storeName + ", storePhoneNumber=" + storePhoneNumber
				+ ", storeAddress=" + storeAddress + "]";
	}

	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getStorePhoneNumber() {
		return storePhoneNumber;
	}

	public void setStorePhoneNumber(String storePhoneNumber) {
		this.storePhoneNumber = storePhoneNumber;
	}

	public Address getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(Address storeAddress) {
		this.storeAddress = storeAddress;
	}
	
	

	

	
}
