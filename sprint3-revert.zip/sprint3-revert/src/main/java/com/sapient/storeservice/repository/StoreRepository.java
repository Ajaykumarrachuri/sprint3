package com.sapient.storeservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sapient.storeservice.models.Store;

public interface StoreRepository extends JpaRepository<Store, Long> {
	List<Store> findByStoreName(String storeName);
}
