package com.sapient.storeservice.exceptions;

public class EmptyIDListException extends RuntimeException{
	  private static final long serialVersionUID = 1L;
	  
	  public EmptyIDListException(String message)
	  {
		  super(message);
	  }

}
